require("prototypes.item")
require("prototypes.fluid")
require("prototypes.recipe")
require("prototypes.technology")